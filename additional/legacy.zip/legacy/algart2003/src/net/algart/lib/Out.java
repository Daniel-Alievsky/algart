/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2001-2003 Daniel Alievsky, AlgART Laboratory (http://algart.net)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package net.algart.lib;

import java.util.*;

/**
 * <p>A collection of static methods providing advanced output
 * to <code>System.out</code>,  mostly for debugging needs.
 * In particular, implements:<ul>
 *
 * <li>different ways for converting objects to strings
 * in addition to standard <code>toString</code> method;
 *
 * <li>automatic convertion of "\n" character to correct
 * system-depended line separator;
 *
 * <li>buffering a lot of <code>println</code> calls.
 * </ul>
 *
 * <p>This class can be executed since JVM 1.0 and can be compiled since JDK 1.1.
 *
 * <p><b>Note!</b> Under JVM&nbsp;1.0, the following methods<ul>
 *    <li>{@link #exp(double, int)}
 *    <li>{@link #exp(double, int, int)}
 *    <li>{@link #spaced(int, char)}
 *    <li>{@link #spaced(long, char)}
 * </ul>returns the standard string representation of the given number,
 * as the standard <code>String.valueOf</code> method. Since JVM&nbsp;1.1,
 * these methods work properly.
 *
 * @version 1.0
 * @author  Daniel Alievsky
 * @since   JVM1.0, JDK1.1
 */

public final class Out implements TrueStatic {
// TrueStatic is necessary because setPrintDelay() should be global

    // Don't let anyone instantiate this class
    private Out() {}

    /**
    * Returns a new string resulting from replacing all occurrences of
    * <code>oldSubstring</code> in the <code>s</code> source string
    * with <code>newSubstring</code>.
    *
    * <p>If <code>s == null</code>, no exceptions are thrown;
    * in this case, the method returns <code>null</code>.
    *
    * <p>If <code>oldSubstring</code> does not occur in the
    * the <code>s</code> source string, then a reference to <code>s</code>
    * object is returned.
    *
    * <p>This method can be a useful addition to the standard <code>String.replace</code>
    * method, especially for debug output. It works more quickly than
    * Java 1.4 <code>String.replaceAll</code> method, and is more simple in use.
    *
    * @param s             the string
    * @param oldSubstring  the old substring
    * @param newSubstring  the new substring
    * @return              a string derived from <code>s</code> string by replacing every
    *    occurrence of <code>oldSubstring</code> with <code>newSubstring</code>
    * @throws NullPointerException       if <code>oldSubstring == null</code> or <code>newSubstring == null</code>
    * @throws IllegalArgumentException   if <code>oldSubstring.length() == 0</code>
    */
    public static String replace(String s, String oldSubstring, String newSubstring) {
        if (s == null)
            return null;
        if (oldSubstring == null) throw new NullPointerException("Null oldSubstring argument in replace method");
        if (newSubstring == null) throw new NullPointerException("Null newSubstring argument in replace method");
        if (oldSubstring.equals(newSubstring))
            return s;
        int len = s.length();
        int oldLen = oldSubstring.length();
        if (oldLen == 0) throw new IllegalArgumentException("Empty oldSubstring argument in replace method");
        int p = s.indexOf(oldSubstring);
        if (p == -1) return s;
        StringBuffer sb = new StringBuffer(len);
        sb.append(s.substring(0,p)).append(newSubstring);
        p += oldLen;
        for (; p < len; ) {
            int q = s.indexOf(oldSubstring,p);
            if (q == -1) break;
            sb.append(s.substring(p,q)).append(newSubstring);
            p = q + oldLen;
        }
        sb.append(s.substring(p));
        return sb.toString();
    }

    /**
    * Replaces every char sequence "Exception" in the string <code>s</code> with
    * the char sequence "[[E]]xception".
    *
    * <p>It allows to avoid wrong signals generated by some IDEs
    * when they detect "Exception" word in the standard application
    * output while debugging the program. For example, Borland JavaBuilder(TM)
    * sounds a clank every time when the debugged application prints "Exception" into
    * <code>System.out</code> or <code>System.err</code>. It's a good idea usually,
    * when the application prints standard exception information (for
    * example, by <code>e.printStackTrace()</code> call). But it can be very
    * bad if you need to print some debugging text containing a lot of
    * "Exception" words while normal execution of the application.
    *
    * <p>This method is called internally by {@link #print(String)} and
    * {@link #println(String)} methods of this class, if you
    * set the corresponding flag by
    * {@link #setAutomaticAvoidingDebugSignalsForExceptions(boolean)}
    * method.
    *
    * @param s   the corrected string; can be <code>null</code>
    * @return    <code>{@link #replace(String, String, String) replace}(s,"Exception","[[E]]xception")</code>;
    *    <code>null</code> if <code>s == null</code>
    * @see #print(String)
    * @see #println(String)
    * @see #setAutomaticAvoidingDebugSignalsForExceptions(boolean)
    */

    public static String avoidDebugSignalsForExceptions(String s) {
        return replace(s,"Exception","[[E]]xception");
    }
    /**
    * Replaces every "\n" character in the string <code>s</code> with
    * {@link GlobalProperties#LINE_SEPARATOR} string.
    *
    * <p>If "\n" character is already a part of some line separator,
    * it is not replaced. So, you can also apply method to texts
    * where the lines are separated by {@link GlobalProperties#LINE_SEPARATOR}.
    *
    * <p>It can simplify generation of a text with lines separated
    * by <code>GlobalProperties.LINE_SEPARATOR</code>.
    *
    * <p>This method is called internally by {@link #print(String)} and
    * {@link #println(String)} methods of this class.
    *
    * @param s   the corrected string; can be <code>null</code>
    * @return    <code>{@link #replace(String, String, String) replace}(s,"\n",GlobalProperties.LINE_SEPARATOR)</code>;
    *    <code>null</code> if <code>s == null</code>
    * @see #print(String)
    * @see #println(String)
    */
    public static String replaceLFToLineSeparator(String s) {
        if (s == null)
            return null;
        if (GlobalProperties.LINE_SEPARATOR.equals("\n"))
            return s;
        int len = s.length();
        int sepLen = GlobalProperties.LINE_SEPARATOR.length();
        StringBuffer sb = new StringBuffer(len);
        for (int pSep = 0; pSep < len; ) {
            int qSep = s.indexOf(GlobalProperties.LINE_SEPARATOR,pSep);
            if (qSep == -1) qSep = len;
            String noSep = s.substring(pSep,qSep); // - this operation is optimized in Java (doesn't copy data)
            // replacing in noSep:
            int noSepLen = qSep-pSep;
            int p = 0;
            for (; p < noSepLen; ) {
                int q = noSep.indexOf("\n",p);
                if (q == -1) break;
                sb.append(noSep.substring(p,q)).append(GlobalProperties.LINE_SEPARATOR);
                p = q + 1;
            }
            sb.append(noSep.substring(p));
            // end of replacing in noSep
            if (qSep == len) break;
            sb.append(GlobalProperties.LINE_SEPARATOR);
            pSep = qSep + sepLen;
        }
        return sb.toString();
    }

    /**
    * Returns a string consisting of <code>len</code> copies of the
    * specified character <code>c</code>.
    *
    * @param c     the character that is duplicated
    * @param len   the number of copies of <code>c</code> characters in the result string
    * @return      a string consisting of <code>len</code> characters, each character is equal to <code>c</code>
    */
    public static String dup(char c, int len) {
        char[] chars = new char[len];
        for (int k = 0; k < len; k++) chars[k] = c;
        return String.valueOf(chars);
    }

    /**
    * If <code>padLen &lt; s.length()</code>, returns a reference to the original
    * <code>s</code> string object; in other case, returns the <code>s</code>
    * padded leftward to <code>padLen</code> length by the space character:<pre>
    *    dup(' ', padLen - s.length()) + s
    * </pre>
    *
    * @param s       the string that should be padded
    * @param padLen  the minimal length of the resulting string
    * @return        the string padded leftward (if necessary) to the <code>padLen</code>
    *    length by the space character
    */
    public static String pad(String s, int padLen) {
        return pad(s,padLen,' ',false);
    }

    /**
    * If <code>padLen &lt; s.length()</code>, returns a reference to the original
    * <code>s</code> string object; in other case, returns the <code>s</code>
    * padded rightward to <code>padLen</code> length by the space character:<pre>
    *    s + dup(' ', padLen - s.length())
    * </pre>
    *
    * @param s       the string that should be padded
    * @param padLen  the minimal length of the resulting string
    * @return        the string padded rightward (if necessary) to the <code>padLen</code>
    *    length by the space character
    */
    public static String rightPad(String s, int padLen) {
        return pad(s,padLen,' ',true);
    }

    /**
    * If <code>padLen &lt; s.length()</code>, returns a reference to the original
    * <code>s</code> string object; in other case, returns the <code>s</code>
    * padded leftward or rightward to <code>padLen</code> length by the given <code>pad</code>
    * character:<pre>
    *    right? s + dup(pad, padLen - s.length()): dup(pad, padLen - s.length()) + s
    * </pre>
    *
    * @param s       the string that should be padded
    * @param padLen  the minimal length of the resulting string
    * @param pad     the character used for padding
    * @param right   if <code>true</code>, the string is padded rightward, else leftward
    * @return        the string padded (if necessary) to the <code>padLen</code>
    *    length by the <code>pad</code> character
    */
    public static String pad(String s, int padLen, char pad, boolean right) {
        if (s.length() >= padLen) return s;
        if (right)
            return s + dup(pad, padLen - s.length());
        else
            return dup(pad, padLen - s.length()) + s;
    }


    /*Repeat()
    integer ==> long ;;
    int v ==> long v
    */
    /**
    * Equivalent to<pre>
    *    pad(String.valueOf(v),padLen)
    * </pre>
    *
    * @param v       the integer number that should be converted to string and padded
    * @param padLen  the minimal number of characters of the resulting string
    * @return        a decimal representation of the given number, padded leftward
    *    (if necessary) to the <code>padLen</code> length by the space character
    * @see #pad(String, int)
    */
    public static String pad(int v, int padLen) {
        return pad(String.valueOf(v),padLen);
    }/*Repeat.AutoGeneratedStart !! Auto-generated: NOT EDIT !! */
    /**
    * Equivalent to<pre>
    *    pad(String.valueOf(v),padLen)
    * </pre>
    *
    * @param v       the long number that should be converted to string and padded
    * @param padLen  the minimal number of characters of the resulting string
    * @return        a decimal representation of the given number, padded leftward
    *    (if necessary) to the <code>padLen</code> length by the space character
    * @see #pad(String, int)
    */
    public static String pad(long v, int padLen) {
        return pad(String.valueOf(v),padLen);
    }/*Repeat.AutoGeneratedEnd*/

    /**
    * Equivalent to<pre>
    *    deTab(s,tabLen,'\n')
    * </pre>
    *
    * @param s       the multiline text where all tab characters (\t) should be replaced with spaces
    * @param tabLen  every \t charater corresponds to <code>tabLen</code> positions
    * @return        an original text where all tab characters (\t) are replaced with spaces
    * @see #deTab(String, int, char)
    */
    public static String deTab(String s, int tabLen) {
        return deTab(s,tabLen,'\n');
    }

    /**
    * Performs standard <i>detab</i> operation with the given tabulation length.
    * All tab characters '\t' are replaced with corresponding number of spaces ' '.
    * This method assumes that the lines in the <code>s</code> text are separated
    * by one character <code>lineSeparator</code> or by a sequence of characters
    * where the last character is <code>lineSeparator</code>. In other words,
    * the position in the line of the first character after each
    * <code>lineSeparator</code> is 0.
    * (We consider that the positions in lines start from 0, not from 1.)
    *
    * <p>For example:<pre>
    *    deTab("\t",4,'\n') == "    "
    *    deTab("aa\tbb",4,'\n') == "aa  bb"
    *    deTab("aa\t\r\n\tbb",4,'\n') == "aa  \r\n    bb"
    * but
    *    deTab("aa\t\n\r\tbb",4,'\n') == "aa  \n\r   bb"
    * </pre>
    *
    * @param s       the multiline text where all tab characters (\t) should be replaced with spaces
    * @param tabLen  every \t charater corresponds to <code>tabLen</code> positions
    * @param lineSeparator the character used for line separation, or the last character
    *    in the sequence that is used for line separation
    * @return        an original text where all tab characters (\t) are replaced with spaces
    */
    public static String deTab(String s, int tabLen, char lineSeparator) {
        if (tabLen <= 0) throw new IllegalArgumentException(Out.class.getName() + "deTab: illegal tabLen argument " + tabLen);
        if (s.indexOf('\t') == -1) return s;
        int len = s.length();
        StringBuffer sb = new StringBuffer(len);
        for (int k = 0, pos = 0; k < len; k++) {
            char c = s.charAt(k);
            if (c == lineSeparator) {
                sb.append(c); pos = 0;
            } else if (c == '\t') {
                do {
                    sb.append(' '); pos++;
                } while (pos%tabLen != 0);
            } else {
                sb.append(c); pos++;
            }
        }
        return sb.toString();
    }

    /**
    * Equivalent to<pre>
    *    deTab(s,tabPositions,'\n')
    * </pre>
    *
    * @param s       the multiline text where all tab characters (\t) should be replaced with spaces
    * @param tabPositions  tabulation positions
    * @return        an original text where all tab characters (\t) are replaced with spaces
    * @see #deTab(String, int)
    * @see #deTab(String, int[], char)
    */
    public static String deTab(String s, int[] tabPositions) {
        return deTab(s,tabPositions,'\n');
    }

    /**
    * Performs <i>detab</i> operation with the given set of tabulation positions.
    * Every tab character '\t' in each line of the text <code>s</code> is replaced
    * with several spaces ' ' (at least by one space) so that the index of the
    * next character in this line becomes equal to the nearest next element of
    * <code>tabPositions</code> array which is &gt;= the current
    * position in the line. If there are no available elements in
    * <code>tabPositions</code> (the array is exhausted), '\t' character
    * is merely replaced with space ' '.
    *
    * <p>More simple method {@link #deTab(String, int, char)} is equivalent
    * to the call of this one when <code>tabPositions</code> array contains
    * an &quot;infinite&quot; (large enough) sequence of integer numbers
    * 8, 16, 24, ..., 8*n, ...
    *
    * <p>This method assumes that the lines in the <code>s</code> text are separated
    * by one character <code>lineSeparator</code> or by a sequence of characters
    * where the last character is <code>lineSeparator</code>. In other words,
    * the position in the line of the first character after each
    * <code>lineSeparator</code> is 0.
    * (We consider that the positions in lines start from 0, not from 1.)
    *
    * <p>For example:<pre>
    *    deTab("\t",new int[] {2},'\n') == "  "
    *    deTab("aa\tbb",new int[0],'\n') == "aa bb"
    *    deTab("aa\tbb\tcc",new int[] {4,10,20},'\n') == "aa  bb    cc"
    * but
    *    deTab("aa\tbb\tcc",new int[] {1,10,20},'\n') == "aa        bb        cc"
    * </pre>In the last case, the first element of <code>tabPositions</code>
    * array is less than the position of the first '\t' character; so,
    * this element was skipped, and elements 10 and 20 were used.
    *
    * <p>This method is very convenient for generating logs and reports
    * formatted by spaces.
    *
    * @param s             the multiline text where all tab characters (\t) should be replaced with spaces
    * @param tabPositions  tabulation positions
    * @param lineSeparator the character used for line separation, or the last character
    *    in the sequence that is used for line separation
    * @return              an original text where all tab characters (\t) are replaced with spaces
    * @see #deTab(String, int, char)
    */
    public static String deTab(String s, int[] tabPositions, char lineSeparator) {
        if (s.indexOf('\t') == -1) return s;
        int len = s.length();
        StringBuffer sb = new StringBuffer(len);
        for (int k = 0, pos = 0, posIndex = 0; k < len; k++) {
            char c = s.charAt(k);
            if (c == lineSeparator) {
                sb.append(c); pos = 0; posIndex = 0;
            } else if (c == '\t') {
                do {
                sb.append(' '); pos++;
                } while (posIndex < tabPositions.length && pos < tabPositions[posIndex]);
                if (posIndex < tabPositions.length) posIndex++;
            } else {
                sb.append(c); pos++;
                while (posIndex < tabPositions.length && pos >= tabPositions[posIndex]) posIndex++;
            }
        }
        return sb.toString();
    }

    /*Repeat()
    byte ==> short,, int,, long ;;
    &0xFF ==> &0xFFFF,, ,, ;;
    2 ==> 4 ,, 8 ,, 16 ;;
    Integer ==> Integer,, Integer,, Long
    */
    /**
    * Returns a hexadecimal unsigned representation of the byte argument.
    * Unlike <code>Integer.toHexString(v)</code> call, the result
    * always contains 2 digits (leaded by '0' if needed).
    *
    * @param v the byte argument
    * @return  its hexadecimal representation (2 characters)
    */
    public static String hex(byte v) {
        return pad(Integer.toHexString(v&0xFF),2,'0',false);
    }/*Repeat.AutoGeneratedStart !! Auto-generated: NOT EDIT !! */
    /**
    * Returns a hexadecimal unsigned representation of the short argument.
    * Unlike <code>Integer.toHexString(v)</code> call, the result
    * always contains 4 digits (leaded by '0' if needed).
    *
    * @param v the short argument
    * @return  its hexadecimal representation (4 characters)
    */
    public static String hex(short v) {
        return pad(Integer.toHexString(v&0xFFFF),4,'0',false);
    }
    /**
    * Returns a hexadecimal unsigned representation of the int argument.
    * Unlike <code>Integer.toHexString(v)</code> call, the result
    * always contains 8 digits (leaded by '0' if needed).
    *
    * @param v the int argument
    * @return  its hexadecimal representation (8 characters)
    */
    public static String hex(int v) {
        return pad(Integer.toHexString(v),8,'0',false);
    }
    /**
    * Returns a hexadecimal unsigned representation of the long argument.
    * Unlike <code>Long.toHexString(v)</code> call, the result
    * always contains 16 digits (leaded by '0' if needed).
    *
    * @param v the long argument
    * @return  its hexadecimal representation (16 characters)
    */
    public static String hex(long v) {
        return pad(Long.toHexString(v),16,'0',false);
    }/*Repeat.AutoGeneratedEnd*/

    /**
    * Returns the string decimal representation of the double argument
    * with <code>d</code> digits after the decimal point. If
    * <code>d &lt;= 0</code>, the mantissa is not included in the result.
    *
    * <p>Examples:<pre>
    *    dec(100*Math.PI,5) == "314.15927",
    *    dec(100.0/3.0,1) == "33.3",
    *    dec(-2.0/3.0,0) == "-1"
    * </pre>
    * As for <code>String.valueOf(v)</code> call, the result is
    * always written in american (scientific) standard, regardless
    * of the current regional settings.
    *
    * @param v the double number
    * @param d the number of digits after the decimal point
    * @return  the decimal representation of the given number
    * @see #exp(double, int)
    */
    public static String dec(double v, int d) {
        return JVM.INTERNAL_COMPATIBILITY_TOOL.decOrExpPrivate(v,d,false);
    }

    /**
    * Returns the string decimal representation of the double argument
    * in exponent form (&quot;scientific&quot; notation) with <code>d</code>
    * digits after the decimal point. If  <code>d &lt;= 0</code>,
    * the mantissa is not included in the result.
    *
    * <p>Examples:<pre>
    *    exp(100*Math.PI,5) == "3.14159E2",
    *    exp(100.0/3.0,5) == "3.3E1",
    *    dec(-2.0/3.0,0) == "-7E-1"
    * </pre>
    * As for <code>String.valueOf(v)</code> call, the result is
    * always written in american (scientific) standard, regardless
    * of the current regional settings.
    *
    * @param v the double number
    * @param d the number of digits after the decimal point
    * @return  the exponent-form representation of the given number
    * @see #dec(double, int)
    */
    public static String exp(double v, int d) {
        return JVM.INTERNAL_COMPATIBILITY_TOOL.decOrExpPrivate(v,d,true);
    }

    /**
    * Equivalent to<pre>
    *    {@link #pad(String, int) pad}({@link #dec(double, int) dec}(v,d),padLen)
    * </pre>
    *
    * @param v       the double number
    * @param d       the number of digits after the decimal point
    * @param padLen  the minimal number of characters in the result
    * @return        the decimal representation of the given number, padded leftward
    *    (if necessary) to the <code>padLen</code> length by the space character
    * @see #exp(double, int, int)
    */
    public static String dec(double v, int d, int padLen) {
        return pad(dec(v,d),padLen);
    }

    /**
    * Equivalent to<pre>
    *    {@link #pad(String, int) pad}({@link #exp(double, int) exp}(v,d),padLen)
    * </pre>
    *
    * @param v       the double number
    * @param d       the number of digits after the decimal point
    * @param padLen  the minimal number of characters in the result
    * @return        the exponent-form representation of the given number, padded leftward
    *    (if necessary) to the <code>padLen</code> length by the space character
    * @see #dec(double, int, int)
    */
    public static String exp(double v, int d, int padLen) {
        return pad(exp(v,d),padLen);
    }

    /**
    * Equivalent to<pre>
    *    {@link #spaced(long, char) spaced(v,space)}
    * </pre>
    *
    * @param v     the integer number
    * @param space the character used for separating terns of digits
    * @return  the decimal representation of the given number in the well-readable form
    */
    public static String spaced(int v, char space) {
        return JVM.INTERNAL_COMPATIBILITY_TOOL.spaced((long)v,space);
    }

    /**
    * Returns the string decimal representation of the long integer argument
    * where all terns of digits (from the right to the left) are separated
    * by the given space character.
    * The result does not regard of the current regional settings.
    * Convenient for showing large integer numbers.
    *
    * <p>Examples:<pre>
    *    spaced(345234,' ') == "345234"
    *    spaced(-2234,',') == "-2,234"
    *    spaced(22,' ') == "22"
    * </pre>
    *
    * @param v     the integer number
    * @param space the character used for separating terns of digits
    * @return  the decimal representation of the given number in the well-readable form
    */
    public static String spaced(long v, char space) {
        return JVM.INTERNAL_COMPATIBILITY_TOOL.spaced(v,space);
    }

    /**
    * Equivalent to<pre>
    *    {@link #abc(long) abc((long)v)}
    * </pre>
    *
    * @param v the integer number
    * @return  the &quot;spreadsheet&quot; representation of the given number
    *    (used for columns in most spreadsheets)
    * @see #parseLongAbc(String)
    */
    public static String abc(int v) {
        return abc((long)v);
    }

    /**
    * Returns the representation of the integer argument in a special
    * &quot;spreadsheet&quot; form: 0 is represented as &quot;A&quot;,
    * 1 as &quot;B&quot;, 2 as &quot;C&quot;, then
    * &quot;D&quot;, &quot;E&quot;, ..., &quot;Z&quot;,
    * &quot;AA&quot;, &quot;AB&quot;, ..., &quot;AZ&quot;,
    * &quot;BA&quot;, &quot;AB&quot;, ..., &quot;ZY&quot;, &quot;ZZ&quot;,
    * &quot;AAA&quot;, &quot;AAB&quot;, ... For negative numbers,
    * minus character is added as for usual representation:
    * -1 is represented as &quot;-B&quot;,
    * -2 as &quot;-C&quot;, etc.
    *
    * @param v the integer number
    * @return  the &quot;spreadsheet&quot; representation of the given number
    *    (used for columns in most spreadsheets)
    * @see #parseLongAbc(String)
    */
    public static String abc(long v) {
        StringBuffer sb = new StringBuffer(8);
        int offset = 0;
        if (v < 0) {
            sb.append('-');
            v = -v;
            offset = 1;
        }
        for (; v >= 0; v = v/26-1) {
            sb.insert(offset,(char)('A' + (char)(v%26)));
        }
        return sb.toString();
    }

    /**
    * Returns such an integer number <code>x</code> that
    * <code>{@link #abc(long) abc(x)}.equals(s)</code>.
    *
    * @param s the string representation of some unknown number in &quot;spreadsheet&quot; form
    * @return  the unknown number
    * @throws NumberFormatException if <code>s</code> is not a valid
    *    &quot;spreadsheet&quot; representation of an integer number
    * @see #abc(int)
    * @see #abc(long)
    */
    public static long parseLongAbc(String s) {
        int offset = 0;
        if (s.startsWith("-")) offset = 1;
        long result = -1, mult = 1;
        for (int p = s.length()-1; p >= offset; p--) {
            char c = s.charAt(p);
            int dig;
            if (c >= 'A' && c <= 'Z') dig=  c-'A';
            else if (c >= 'a' && c <= 'z') dig = c-'a';
            else throw new NumberFormatException("Illegal character: " + c);
            result += (dig + 1) * mult;
            mult *= 26;
        }
        if (mult == 1) throw new NumberFormatException("Empty string");
        if (offset == 1) result = -result;
        return result;
    }

    /**
    * If <code>o</code> is an instance of Java array, standard collection,
    * map (or Java 1 <code>Dictionary</code>), <code>Iterator</code>
    * (or Java 1 <code>Enumeration</code>), joins and returns as a string
    * the standard string representations for all elements of this array
    * (or collection, or all objects returned by the iterator),
    * separating elements by the given <code>separator</code>.
    * For all kinds of maps, joins &quot;key=value&quot; pairs instead
    * elements. For <code>null</code>, returns an empty string.
    * For all other classes of <code>o</code> object,
    * throws an exception.
    *
    * <p>Convenient while debugging the code processing not-too-large
    * arrays and collections.
    *
    * <p>Examples:<pre>
    *    join(new int[] {1,2,3},",") == "1,2,3"
    *    join(new ArrayList(),";") == ""
    *    join(null,",") == ""
    * </pre>
    *
    * @param o         the given array, collection, map, iterator, or <code>null</code> value
    * @param separator the string used for separating elements
    * @return          the string representations of all elements joined into one string
    * @throws IllegalArgumentException if the class of <code>o</code> argument is unsuitable
    */
    public static String join(Object o, String separator) {
        String result = JVM.INTERNAL_COMPATIBILITY_TOOL.join(o,separator);
        if (result == null)
            throw new IllegalArgumentException("Illegal argument type in " + Out.class.getName() + ".join method: " + o.getClass());
        return result;
    }



    /**
    * Prints the given string on <code>System.out</code>. Unlike the standard
    * <code>System.out.print</code> method, this one perform the following
    * additional actions.<ol>
    *
    * <li>The replacements provided by {@link #replaceLFToLineSeparator(String)}
    * are performed ("<code>value&nbsp;=&nbsp;replaceLFToLineSeparator(value)</code>").
    * So, this method can be safely use for printing
    * several lines in one simple call, such as<pre>
    *    Out.print("First line\nSecond line")</pre>
    *
    * <li>Then, if the global flag, customized by
    * {@link #setAutomaticAvoidingDebugSignalsForExceptions(boolean)}
    * method, is set, the replacements provided by
    * {@link #avoidDebugSignalsForExceptions(String)}
    * are performed  ("<code>value&nbsp;=&nbsp;avoidDebugSignalsForExceptions(value)</code>").
    *
    * <li>If some print delay was set by {@link #setPrintDelay(long)} call,
    * then the resulting string will not be printed immediately. Instead,
    * it will be added to an internal buffer that will be fully printed
    * (using <code>System.out.print(buffer)</code> call) after
    * the specified delay <i>following the last call of
    * this method</i> (or {@link #println(String)} method, or
    * {@link #printNoCorrections(String)}).
    * If no print delay was specified, the resulting string will
    * be just printed by <code>System.out.print(value)</code>
    * call. Such a delay can greatly increase output performance,
    * especially while debugging under some IDE.
    *
    * @param value the printed string; if <code>null</code>, the <code>"null"</code>
    *    string will be printed
    * @see #replaceLFToLineSeparator(String)
    * @see #avoidDebugSignalsForExceptions(String)
    * @see #setAutomaticAvoidingDebugSignalsForExceptions(boolean)
    * @see #flush()
    * @see #setPrintDelay(long)
    * @see #println(String)
    */
    public static void print(String value) {
        value = replaceLFToLineSeparator(value);
        if (automaticAvoidingDebugSignalsForExceptions)
            value = avoidDebugSignalsForExceptions(value);
        printNoCorrections(value);
    }
    /**
    * A brief equivalent of two <code>{@link #print(String) print(value)};
    * {@link #flush()}</code> calls.
    *
    * @param value   the printed string
    * @see #print(String)
    * @see #flush()
    */
    public static void printFlush(String value) {
        print(value);
        flush();
    }
    /**
    * A brief equivalent of <code>{@link #println(String) println}("")</code>
    * call (or <code>{@link #print(String) print}("\n")</code>: remind that
    * {@link #print(String) print} method automatically replaces "\n"
    * with {@link GlobalProperties#LINE_SEPARATOR}).
    *
    * @see #print(String)
    * @see #println(String)
    */
    public static void println() {
        print("\n");
    }
    /**
    * A brief equivalent of two <code>{@link #println(String) println(value)};
    * {@link #flush()}</code> calls.
    *
    * @param value   the printed string
    * @see #println(String)
    * @see #flush()
    */
    public static void printlnFlush(String value) {
        println(value);
        flush();
    }
    /**
    * This method differs from <code>System.out.println</code> in the same
    * respects as the {@link #print(String)} method differs from
    * <code>System.out.print</code>. It's equivalent to<pre>
    *    print(value + "\n");
    * </pre>call. ({@link #print(String) print} call automatically replaces "\n"
    * with {@link GlobalProperties#LINE_SEPARATOR}.)
    *
    * @param value the printed string (followed by {@link GlobalProperties#LINE_SEPARATOR line separator}).
    * @see #replaceLFToLineSeparator(String)
    * @see #avoidDebugSignalsForExceptions(String)
    * @see #setAutomaticAvoidingDebugSignalsForExceptions(boolean)
    * @see #flush()
    * @see #setPrintDelay(long)
    * @see #print(String)
    */
    public static void println(String value) {
        print(value + "\n");
    }


    /**
    * An analog of {@link #print(String)} method that doesn't perform any
    * replacements in the <code>value</code> string. So, it only
    * performs a delay before printing (if it was set by
    * {@link #setPrintDelay(long)} call) in addition to standard
    * <code>System.out.print</code> actions.
    *
    * @param value   the printed string
    * @see #print(String)
    */
    public static void printNoCorrections(String value) {
        if (printDelay <= 0) {
            System.out.print(value); return;
        }
        LazyPrintHolder.print(value);
    }


    /**
    * Immediately flushs the buffer filled by previous calls of {@link #print(String)},
    * {@link #println(String)},
    * {@link #printNoCorrections(String)}
    * to the <code>System.out</code>.
    * Does nothing if no positive delay was specified by
    * {@link #setPrintDelay(long)} call.
    *
    * <p>Also, regardless on the delay value, this method
    * calls <code>flush()</code> methods for all objects
    * registered by {@link #addFlusher(Out.Flusher)} method.
    *
    * <p>This method is useful only if you need to synchronize
    * the output performed by this class and the standard
    * output tools such as direct <code>System.out.println</code>
    * calls or printing to <code>System.err</code> (that is
    * not buffered by this class at all).
    *
    * @see #print(String)
    * @see #println(String)
    * @see #setPrintDelay(long)
    */
    public static void flush() {
        if (printDelay <= 0) return;
        LazyPrintHolder.flush();
        for (Enumeration en = flushers.keys(); en.hasMoreElements(); ) {
            ((Flusher)en.nextElement()).flush();
        }
    }


    /**
    * Sets the delay performed after the last call of {@link #print(String)},
    * {@link #println(String)},
    * {@link #printNoCorrections(String)}
    * methods until the moment when the printed text will
    * be really sent to <code>System.out</code> (by <code>System.out.print</code>
    * call). This value is global for this class and usually should be set only
    * once at the start of your application.
    *
    * @param ms  new delay in milliseconds; <code>0</code> value (which is default)
    *    means that no delay will be performed
    * @throws IllegalArgumentException   if <code>ms &lt; 0</code>
    * @see #print(String)
    * @see #println(String)
    * @see #flush()
    */
    public static void setPrintDelay(long ms) {
        if (ms < 0) throw new IllegalArgumentException("Negative argument in " + Out.class.getName() + ".setPrintDelay method");
        Out.flush();
        printDelay = ms;
    }
    /**
    * Returns the print delay set by the last {@link #setPrintDelay(long)} call.
    * Return (<code>0</code> before the first call of {@link #setPrintDelay(long)}.
    *
    * @return  the print delay set by the last {@link #setPrintDelay(long)} call
    */
    public static long getPrintDelay() {
        return printDelay;
    }

    /**
    * Sets the flag defining whether {@link #print(String)} and
    * {@link #println(String)} methods should perform replacements
    * provided by {@link #avoidDebugSignalsForExceptions(String)}
    * method in the printed text. This flag is global for this class
    * and usually should be set only once at the start of your application.
    * Default value of this flag if <code>false</code> (no replacements).
    * We recommend to set this flag to <code>true</code> in large
    * applications that use console for debugging needs.
    *
    * @param value  new value of this flag
    * @see #print(String)
    * @see #println(String)
    * @see #avoidDebugSignalsForExceptions(String)
    */
    public static void setAutomaticAvoidingDebugSignalsForExceptions(boolean value) {
        automaticAvoidingDebugSignalsForExceptions = value;
    }
    /**
    * Returns the global flag set by the last {@link
    * #setAutomaticAvoidingDebugSignalsForExceptions(boolean)} call
    * (<code>false</code> by default).
    *
    * @return  the global flag set by the last {@link
    *   #setAutomaticAvoidingDebugSignalsForExceptions(boolean)} call
    */
    public static boolean isAutomaticAvoidingDebugSignalsForExceptions() {
        return automaticAvoidingDebugSignalsForExceptions;
    }

    /**
    * See {@link Out#flush()} method.
    */
    public interface Flusher {
        public void flush();
    }

    private static Hashtable flushers = new Hashtable();
    /**
    * Registers (adds to the internal list) a flusher,
    * that (it's <code>flush()</code> method) will be called
    * in the {@link #flush()} method.
    *
    * @param flusher New registered flusher.
    * @see #removeFlusher(Out.Flusher)
    * @see #flush()
    */
    public static void addFlusher(Flusher flusher) {
        if (flusher == null) throw new NullPointerException("Null argument in " + Out.class.getName() + ".addFlusher method");
        flushers.put(flusher,"dummy");
    }
    /**
    * Deregisters (removes from the internal list) the given flusher.
    *
    * @param flusher New registered flusher.
    * @see #addFlusher(Out.Flusher)
    * @see #flush()
    */
    public static void removeFlusher(Flusher flusher) {
        if (flusher == null) throw new NullPointerException("Null argument in " + Out.class.getName() + ".removeFlusher method");
        flushers.remove(flusher);
    }

    private static Object lazyPrintLock = new Object();
    private static class LazyPrint extends Thread {
        public void run() {
            synchronized(lazyPrintLock) {
                LazyPrintHolder.running = true;
                try {
                    long t;
                    while ((t = System.currentTimeMillis()) < LazyPrintHolder.printTime
                        && LazyPrintHolder.printBuffer != null)
                        lazyPrintLock.wait(LazyPrintHolder.printTime - t);
                } catch (InterruptedException e) {
                }
                LazyPrintHolder.flush();
                LazyPrintHolder.running = false;
            }
        }
    }
    private static class LazyPrintHolder {
        private static long printTime = Long.MAX_VALUE;
        private static StringBuffer printBuffer = null;
        private static boolean running = false;
        public static void print(String value) {
            synchronized(lazyPrintLock) {
                if (printBuffer == null)
                    printBuffer= new StringBuffer(value);
                else
                    printBuffer.append(value);
                printTime = System.currentTimeMillis() + printDelay;
                if (!running) new LazyPrint().start();
                lazyPrintLock.notifyAll();
            }
        }
        public static synchronized void flush() {
            synchronized(lazyPrintLock) {
                if (printBuffer != null) {
                    System.out.print(printBuffer);
                    printBuffer = null;
                    lazyPrintLock.notifyAll();
                }
            }
        }
    }

    private static boolean automaticAvoidingDebugSignalsForExceptions = false;
    private static long printDelay = 0;
}